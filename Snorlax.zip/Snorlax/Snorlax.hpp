#ifndef YP_SNORLAX_HPP
#define YP_SNORLAX_HPP

#include "CGLabmain.hpp"

namespace Snorlax {

class MyVirtualWorld {
public:
    MyVirtualWorld();
    void init();          // Initialize Snorlax
    void draw();          // Draw Snorlax model
    void tickTime();      // Update model (for animation, if needed)

private:
    float size;  // Add size as a member variable
    float xPos, yPos, zPos; // Position variables
    float bodyRadius;
    GLUquadric* body;
    int slices;
    int stacks;
    void drawBody();      // Draw Snorlax's body (ellipsoid)
    void drawArms();      // Draw Snorlax's arms
    void drawLegs();      // Draw Snorlax's legs
    void drawFace();      // Draw Snorlax's face (eyes, mouth, etc.)
};

} // namespace Snorlax

#endif // YP_SNORLAX_HPP
