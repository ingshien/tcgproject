#include <GL/glut.h>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include "Snorlax.hpp"

using namespace Snorlax;
float deform(float y) {
// Makes the bottom wider and top slightly narrower � Snorlax belly-like
float normalizedY = (y + 1.0f) / 2.0f; // Normalize y from \[-1,1] to \[0,1]
return 0.9f + 0.25f * sinf(normalizedY * M_PI);  // Rounded sides, flat bottom
}

MyVirtualWorld::MyVirtualWorld() {
// Constructor: Initialize Snorlax properties if needed
bodyRadius = 6.0f;  // Example value for body radius (adjust as needed)
body = gluNewQuadric();  // Create a new quadric object for drawing spheres
slices = 32;  // Number of slices for spheres
stacks = 32;  // Number of stacks for spheres
}

void MyVirtualWorld::init() {
// Initialize any properties for Snorlax
}

void MyVirtualWorld::tickTime() {
// If you need animation, update positions or properties over time
}

void MyVirtualWorld::draw() {
// Draw Snorlax by drawing each body part
drawBody();
drawArms();
drawLegs();
drawFace();
}

void MyVirtualWorld::drawBody() {
const int stacks = 40;
const int slices = 40;
const float radius = 1.0f;
const float yStrecth = 2.0f;

glPushMatrix();
glTranslatef(0.0f, 0.0f, 0.0f);  // Shift belly upward
glScalef(6.0f, 6.0f * yStrecth, 6.0f);    // Enlarge the shape
glColor3f(0.1608f, 0.4510f, 0.5569f);

for (int i = 0; i < stacks; ++i) {
    float phi1 = M_PI * i / stacks;
    float phi2 = M_PI * (i + 1) / stacks;

    glBegin(GL_TRIANGLE_STRIP);
    for (int j = 0; j <= slices; ++j) {
        float theta = 2 * M_PI * j / slices;

        for (int k = 0; k < 2; ++k) {
            float phi = (k == 0) ? phi1 : phi2;

            float y = radius * cos(phi);
            float deformFactor = deform(y);

            float x = radius * sin(phi) * cos(theta) * deformFactor;
            float z = radius * sin(phi) * sin(theta) * deformFactor;

            // Smooth flattening at the bottom
            float yNormalized = (y + 0.5f) / 2.0f; // [0,1]
            float squashFactor = 1.0f;
            if (y < 0.0f) {
                squashFactor = 0.5f + 0.4f * sinf((yNormalized) * M_PI_2); // Smooth squash for lower half
            } else {
                squashFactor = 0.9f; // Slight flattening for upper part
            }

            float ySmoothed = y * squashFactor;

            glVertex3f(x, ySmoothed, z);
        }
    }
    glEnd();
}

glPopMatrix();

//inner body
    const int inner_stacks = 15;
    const int inner_slices = 20;
    const float flattenFactor = 1.0f;
    const float innerbody = bodyRadius * 0.35f;

    glPushMatrix();
    glTranslatef(innerbody * 0.0f, innerbody * 2.0f, innerbody * 1.97f);
    glRotatef(90, 0.0f, 1.0f, 0.0f);
    glRotatef(70, 0.0f, 0.0f, 1.0f);
    glScalef(3.0f, flattenFactor, 2.5f);
    glColor3f(0.95f, 0.95f, 0.85f);
    glutSolidSphere(innerbody, inner_slices, inner_stacks);
    glPopMatrix();
}

void MyVirtualWorld::drawArms() {
glPushMatrix();
glTranslatef(bodyRadius*0.9f, 6.0f, bodyRadius*0.0f);
glRotatef(-45.0f, 0.0f, 0.0f, 1.0f);
glScalef(6.0f, 2.0f, 2.5f);
glColor3f(0.1608f, 0.4510f, 0.5569f);
glutSolidSphere(bodyRadius/8.0f, slices, stacks);
glPopMatrix();

glPushMatrix();
glTranslatef(-bodyRadius*0.9f, 6.0f, bodyRadius*0.0f);
glRotatef(45.0f, 0.0f, 0.0f, 1.0f);
glScalef(6.0f, 2.0f, 2.5f);
glColor3f (0.1608f, 0.4510f, 0.5569f);
glutSolidSphere(bodyRadius/8.0f, slices, stacks);
glPopMatrix();

//left claws
glPushMatrix();
glTranslatef(-8.0f , 3.5f,  1.0f);  // Position claws around the arm
glRotatef(-45, 0.0f, 1.0f, 0.0f);
glRotatef(45, 1.0f, 0.0f, 0.0f); // Rotate around the arm
glScalef(2.5f, 2.7f, 2.5f);  // Small cylinder size (adjust as needed)
glColor3f(1.0f, 1.0f, 1.0f);  // Claw color (light brown)
glutSolidCone(0.1f, 0.2f, 8, 8);  // Small cone for each claw (cylinder like)
glPopMatrix();

glPushMatrix();
glTranslatef(-8.5f , 3.2f,  0.5f);  // Position claws around the arm
glRotatef(-70, 0.0f, 1.0f, 0.0f);
glRotatef(45, 1.0f, 0.0f, 0.0f); // Rotate around the arm
glScalef(2.5f, 2.7f, 2.5f);  // Small cylinder size (adjust as needed)
glColor3f(1.0f, 1.0f, 1.0f);  // Claw color (light brown)
glutSolidCone(0.1f, 0.2f, 8, 8);  // Small cone for each claw (cylinder like)
glPopMatrix();

glPushMatrix();
glTranslatef(-8.6f , 3.0f,  -0.0f);  // Position claws around the arm
glRotatef(-90, 0.0f, 1.0f, 0.0f);
glRotatef(45, 1.0f, 0.0f, 0.0f); // Rotate around the arm
glScalef(2.2f, 2.4f, 2.2f);  // Small cylinder size (adjust as needed)
glColor3f(1.0f, 1.0f, 1.0f);  // Claw color (light brown)
glutSolidCone(0.1f, 0.2f, 8, 8);  // Small cone for each claw (cylinder like)
glPopMatrix();

glPushMatrix();
glTranslatef(-8.5f , 3.1f,  -0.5f);  // Position claws around the arm
glRotatef(-105, 0.0f, 1.0f, 0.0f);
glRotatef(45, 1.0f, 0.0f, 0.0f); // Rotate around the arm
glScalef(2.5f, 2.7f, 2.5f);  // Small cylinder size (adjust as needed)
glColor3f(1.0f, 1.0f, 1.0f);  // Claw color (light brown)
glutSolidCone(0.1f, 0.2f, 8, 8);  // Small cone for each claw (cylinder like)
glPopMatrix();

glPushMatrix();
glTranslatef(-8.2f , 3.4f,  -0.8f);  // Position claws around the arm
glRotatef(-150, 0.0f, 1.0f, 0.0f);
glRotatef(45, 1.0f, 0.0f, 0.0f); // Rotate around the arm
glScalef(2.5f, 2.7f, 2.5f);  // Small cylinder size (adjust as needed)
glColor3f(1.0f, 1.0f, 1.0f);  // Claw color (light brown)
glutSolidCone(0.1f, 0.2f, 8, 8);  // Small cone for each claw (cylinder like)
glPopMatrix();

//right claws
glPushMatrix();
glTranslatef(8.0f, 3.5f,  1.0f);  // Position claws around the right arm
glRotatef(45, 0.0f, 1.0f, 0.0f);
glRotatef(45, 1.0f, 0.0f, 0.0f); // Rotate around the right arm
glScalef(2.5f, 2.7f, 2.5f);  // Small cylinder size (adjust as needed)
glColor3f(1.0f, 1.0f, 1.0f);  // Claw color (light brown)
glutSolidCone(0.1f, 0.2f, 8, 8);  // Small cone for each claw (cylinder like)
glPopMatrix();

glPushMatrix();
glTranslatef(8.5f, 3.2f,  0.5f);  // Position claws around the right arm
glRotatef(70, 0.0f, 1.0f, 0.0f);
glRotatef(45, 1.0f, 0.0f, 0.0f); // Rotate around the right arm
glScalef(2.5f, 2.7f, 2.5f);  // Small cylinder size (adjust as needed)
glColor3f(1.0f, 1.0f, 1.0f);  // Claw color (light brown)
glutSolidCone(0.1f, 0.2f, 8, 8);  // Small cone for each claw (cylinder like)
glPopMatrix();

glPushMatrix();
glTranslatef(8.6f, 3.0f,  -0.0f);  // Position claws around the right arm
glRotatef(90, 0.0f, 1.0f, 0.0f);
glRotatef(45, 1.0f, 0.0f, 0.0f); // Rotate around the right arm
glScalef(2.2f, 2.4f, 2.2f);  // Small cylinder size (adjust as needed)
glColor3f(1.0f, 1.0f, 1.0f);  // Claw color (light brown)
glutSolidCone(0.1f, 0.2f, 8, 8);  // Small cone for each claw (cylinder like)
glPopMatrix();

glPushMatrix();
glTranslatef(8.5f, 3.1f,  -0.5f);  // Position claws around the right arm
glRotatef(105, 0.0f, 1.0f, 0.0f);
glRotatef(45, 1.0f, 0.0f, 0.0f); // Rotate around the right arm
glScalef(2.5f, 2.7f, 2.5f);  // Small cylinder size (adjust as needed)
glColor3f(1.0f, 1.0f, 1.0f);  // Claw color (light brown)
glutSolidCone(0.1f, 0.2f, 8, 8);  // Small cone for each claw (cylinder like)
glPopMatrix();

glPushMatrix();
glTranslatef(8.2f, 3.4f,  -0.8f);  // Position claws around the right arm
glRotatef(150, 0.0f, 1.0f, 0.0f);
glRotatef(45, 1.0f, 0.0f, 0.0f); // Rotate around the right arm
glScalef(2.5f, 2.7f, 2.5f);  // Small cylinder size (adjust as needed)
glColor3f(1.0f, 1.0f, 1.0f);  // Claw color (light brown)
glutSolidCone(0.1f, 0.2f, 8, 8);  // Small cone for each claw (cylinder like)
glPopMatrix();
}


void MyVirtualWorld::drawLegs() {
// Draw Snorlax's legs
const int stacks = 15;
const int slices = 20;
const float flattenFactor = 0.5f; // How much to flatten the bun vertically
const float legSize = bodyRadius * 0.35f; // Adjust size relative to body

// Draw both legs (left and right)
for (int i = 0; i < 2; ++i) { // i = 0 for left leg, i = 1 for right leg
    float xOffset = (i == 0) ? -legSize * 2.0f : legSize * 2.0f; // Position left or right
    float rotationAngle = (i == 0) ? -15.0f : 15.0f; // Angle for each leg

    glPushMatrix();
    glTranslatef(xOffset, -legSize * 2.0f, legSize * 0.0f); // Position the leg
    glRotatef(90, 0.0f, 1.0f, 0.0f); // Slight rotation for angle

    // Flatten the bun and draw
    glScalef(1.3f, flattenFactor, 1.0f);
    glColor3f(0.8078f, 0.7569f, 0.7216f);
    glutSolidSphere(legSize, slices, stacks);


    glPopMatrix();
}

//left claws
glPushMatrix();
glTranslatef(-3.0f , -4.3f,  2.0f);  // Position claws around the arm
glRotatef(20, 0.0f, 1.0f, 0.0f);
glRotatef(0, 1.0f, 0.0f, 0.0f); // Rotate around the arm
glScalef(3.5f, 3.7f, 3.5f);  // Small cylinder size (adjust as needed)
glColor3f(1.0f, 1.0f, 1.0f);  // Claw color (light brown)
glutSolidCone(0.1f, 0.4f, 35, 10);  // Small cone for each claw (cylinder like)
glPopMatrix();

glPushMatrix();
glTranslatef(-4.3f , -4.3f,  2.5);  // Position claws around the arm
glRotatef(0, 0.0f, 1.0f, 0.0f);
glRotatef(0, 1.0f, 0.0f, 0.0f); // Rotate around the arm
glScalef(3.5f, 3.7f, 3.5f);  // Small cylinder size (adjust as needed)
glColor3f(1.0f, 1.0f, 1.0f);  // Claw color (light brown)
glutSolidCone(0.1f, 0.4f, 35, 10);  // Small cone for each claw (cylinder like)
glPopMatrix();

glPushMatrix();
glTranslatef(-5.3f , -4.3f,  2.0f);  // Position claws around the arm
glRotatef(-30, 0.0f, 1.0f, 0.0f);
glRotatef(0, 1.0f, 0.0f, 0.0f); // Rotate around the arm
glScalef(3.5f, 3.7f, 3.5f);  // Small cylinder size (adjust as needed)
glColor3f(1.0f, 1.0f, 1.0f);  // Claw color (light brown)
glutSolidCone(0.1f, 0.4f, 35, 10);  // Small cone for each claw (cylinder like)
glPopMatrix();

// Right claws
glPushMatrix();
glTranslatef(3.0f, -4.3f, 2.0f);  // Mirror X position from -3.0f to 3.0f
glRotatef(-20, 0.0f, 1.0f, 0.0f); // Flip Y-axis rotation sign from 20 to -20
glRotatef(0, 1.0f, 0.0f, 0.0f);
glScalef(3.5f, 3.7f, 3.5f);
glColor3f(1.0f, 1.0f, 1.0f);
glutSolidCone(0.1f, 0.4f, 35, 10);
glPopMatrix();

glPushMatrix();
glTranslatef(4.3f, -4.3f, 2.5f);  // Mirror X position from -4.3f to 4.3f
glRotatef(0, 0.0f, 1.0f, 0.0f);
glRotatef(0, 1.0f, 0.0f, 0.0f);
glScalef(3.5f, 3.7f, 3.5f);
glColor3f(1.0f, 1.0f, 1.0f);
glutSolidCone(0.1f, 0.4f, 35, 10);
glPopMatrix();

glPushMatrix();
glTranslatef(5.3f, -4.3f, 2.0f);  // Mirror X position from -5.3f to 5.3f
glRotatef(30, 0.0f, 1.0f, 0.0f); // Flip rotation from -30 to 30
glRotatef(0, 1.0f, 0.0f, 0.0f);
glScalef(3.5f, 3.7f, 3.5f);
glColor3f(1.0f, 1.0f, 1.0f);
glutSolidCone(0.1f, 0.4f, 35, 10);
glPopMatrix();

}


void MyVirtualWorld::drawFace() {
// Draw Snorlax's head
glPushMatrix();
glTranslatef(0.0f, 10.5f, 0.0f);
glScalef(2.0f, 2.0f, 2.0f);
glColor3f(0.1608f, 0.4510f, 0.5569f);
glutSolidSphere(1.5f, 32,32);

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_STENCIL_TEST);

    // Clear stencil buffer before use
    glClearStencil(0);
    glClear(GL_STENCIL_BUFFER_BIT);

    // Step 1: Render the cone into stencil buffer
    glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);  // Disable color output
    glDepthMask(GL_FALSE);                                // Disable depth write

    glEnable(GL_CULL_FACE);
    glCullFace(GL_FRONT);  // Cull front faces to create a stencil mask

    glStencilFunc(GL_ALWAYS, 1, 0xFF);
    glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);  // Set stencil to 1 where cone is drawn

glPushMatrix();
glTranslatef(0.0f, 0.8f, 0.8f);  // Position it
glRotatef(180, 1, 0, 0);
glRotatef(-135, 0, 0, 1);

        // Point toward the sphere

float thickness = 0.5f;  // Adjust thickness here

// Define front face (z = 0)
glBegin(GL_TRIANGLES);
glVertex3f(0.0f, 0.0f, 0.0f);  // Right angle corner
glVertex3f(0.6f, 0.0f, 0.0f);  // Base corner
glVertex3f(0.0f, 0.6f, 0.0f);  // Height corner
glEnd();

// Define back face (z = -thickness)
glBegin(GL_TRIANGLES);
glVertex3f(0.0f, 0.0f, -thickness);
glVertex3f(0.6f, 0.0f, -thickness);
glVertex3f(0.0f, 0.6f, -thickness);
glEnd();

// Connect the edges using quads
glBegin(GL_QUADS);
// Side 1 (base)
glVertex3f(0.0f, 0.0f, 0.0f);
glVertex3f(0.6f, 0.0f, 0.0f);
glVertex3f(0.6f, 0.0f, -thickness);
glVertex3f(0.0f, 0.0f, -thickness);

// Side 2 (height)
glVertex3f(0.0f, 0.0f, 0.0f);
glVertex3f(0.0f, 0.6f, 0.0f);
glVertex3f(0.0f, 0.6f, -thickness);
glVertex3f(0.0f, 0.0f, -thickness);

// Side 3 (hypotenuse)
glVertex3f(0.6f, 0.0f, 0.0f);
glVertex3f(0.0f, 0.6f, 0.0f);
glVertex3f(0.0f, 0.6f, -thickness);
glVertex3f(0.6f, 0.0f, -thickness);
glEnd();

glPopMatrix();


    glDisable(GL_CULL_FACE);

    // Step 2: Render the sphere only where stencil != 1 (i.e., subtract the cone)
    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);  // Enable color output
    glDepthMask(GL_TRUE);                             // Enable depth write

    glStencilFunc(GL_NOTEQUAL, 1, 0xFF);
    glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);  // Don't change stencil

    glPushMatrix();
    glTranslatef(-0.0f, 0.0f, 0.65f); // Position it slightly forward
    glScalef(0.85f, 0.8f, 0.6f);    // Slightly squashed
    glColor3f(0.95f, 0.95f, 0.85f);  // Cream color
    glutSolidSphere(1.5f, 32, 32);
    glPopMatrix();

    // Disable stencil test after use
    glDisable(GL_STENCIL_TEST);

// Left Eye
glColor3f(0.0f, 0.0f, 0.0f);  // Light blue color
    glLineWidth(1.5f); // Line thickness
    glTranslatef(-0.7f, 0.5f, 1.3f);
    glRotatef(-20, 0, 1, 0);
    glRotatef(5, 0, 0, 1);

float scale = 0.5f;  // Try values between 0.1 and 1.0 to reduce length

glBegin(GL_LINE_STRIP);
for (float t = 0.0f; t <= 1.0f; t += 0.01f) {
    float x = (1 - t) * (1 - t) * 0.0f + 2 * (1 - t) * t * 0.5f + t * t * 1.0f;
    float y = (1 - t) * (1 - t) * 0.0f + 2 * (1 - t) * t * 0.2f + t * t * 0.0f;
    glVertex3f(x * scale, y * scale, 0.0f);  // Curve scaled smaller
}
glEnd();

// Right Eye
glColor3f(0.0f, 0.0f, 0.0f);  // Light blue color
    glLineWidth(1.5f); // Line thickness
    glTranslatef(0.9f, -0.05f, -0.1f);
    glRotatef(30, 0, 1, 0);
    glRotatef(-2, 0, 0, 1);

glBegin(GL_LINE_STRIP);
for (float t = 0.0f; t <= 1.0f; t += 0.01f) {
    float x = (1 - t) * (1 - t) * 0.0f + 2 * (1 - t) * t * 0.5f + t * t * 1.0f;
    float y = (1 - t) * (1 - t) * 0.0f + 2 * (1 - t) * t * 0.2f + t * t * 0.0f;
    glVertex3f(x * scale, y * scale, 0.0f);  // Curve scaled smaller
}
glEnd();

glPopMatrix();  // Restore transformation state

// Left ear
glPushMatrix();
glTranslatef(-1.6f, 12.6f, 0.0f);  // Mirror X position from -3.0f to 3.0f
glRotatef(-100, 0.0f, 1.0f, 0.0f); // Flip Y-axis rotation sign from 20 to -20
glRotatef(-55, 1.0f, 0.0f, 0.0f);
glScalef(3.5f, 3.7f, 3.5f);
glColor3f(0.1608f, 0.4510f, 0.5569f);
glutSolidCone(0.25f, 0.4f, 32, 10);
glPopMatrix();


// right ear
glPushMatrix();
glTranslatef(1.6f, 12.6f, 0.0f);  // Mirror X position from -3.0f to 3.0f
glRotatef(100, 0.0f, 1.0f, 0.0f); // Flip Y-axis rotation sign from 20 to -20
glRotatef(-55, 1.0f, 0.0f, 0.0f);
glScalef(3.5f, 3.7f, 3.5f);
glColor3f(0.1608f, 0.4510f, 0.5569f);
glutSolidCone(0.25f, 0.4f, 32, 10);
glPopMatrix();

// Mouth (add this right before the final glPopMatrix() for the face)
glPushMatrix();  // Save current transformation state
glTranslatef(0.0f, 10.5f, -0.05f);  // Match head position
glScalef(2.0f, 2.0f, 2.0f);  // Match head scale


glPushMatrix();  // Additional push for mouth-specific transforms
glTranslatef(0.0f, 0.0f, 1.6f);  // Position below eyes
glRotatef(180, 0, 1, 0);  // Face forward
glColor3f(0.0f, 0.0f, 0.0f);  // Black color for mouth
glLineWidth(1.5f);

// Draw mouth curve
glBegin(GL_LINE_STRIP);
for (float t = 0.0f; t <= 1.0f; t += 0.01f) {
    float x = (1 - t) * (1 - t) * -0.3f + 2 * (1 - t) * t * 0.0f + t * t * 0.3f;
    float y = (1 - t) * (1 - t) * 0.0f + 2 * (1 - t) * t * -0.05f + t * t * 0.0f;
    glVertex3f(x, y, 0.0f);
}
glEnd();

glPopMatrix();  // Restore mouth transforms
glPopMatrix();

//Teeth
glPushMatrix();
glTranslatef(-0.4f, 10.5f, 3.0f);  // Mirror X position from -3.0f to 3.0f
glRotatef(-100, 0.0f, 1.0f, 0.0f); // Flip Y-axis rotation sign from 20 to -20
glRotatef(-95, 1.0f, 0.0f, 0.0f);
glScalef(3.0f, 3.2f, 3.0f);
glColor3f(1.0f, 1.0f, 1.0f);
glutSolidCone(0.05f, 0.17f, 32, 10);
glPopMatrix();

glPushMatrix();
glTranslatef(0.4f, 10.5f, 3.0f);  // Mirror X position from -3.0f to 3.0f
glRotatef(-100, 0.0f, 1.0f, 0.0f); // Flip Y-axis rotation sign from 20 to -20
glRotatef(-95, 1.0f, 0.0f, 0.0f);
glScalef(3.0f, 3.2f, 3.0f);
glColor3f(1.0f, 1.0f, 1.0f);
glutSolidCone(0.05f, 0.17f, 32, 10);
glPopMatrix();
}
