#include "battleground.hpp"
#include <GL/glut.h>
#include <cmath>

namespace BattleGround {

    const float platform_radius = 4.0f;
    const float platform_height = 0.06f;
    const int platform_segments = 120;
    const int star_points = 8;
    const float star_outer_radius = 1.55f;
    const float star_inner_radius = 0.64f;

    void drawPlatformBase() {
        float layerStep = 0.02f;
        for (float h = 0; h < platform_height; h += layerStep) {
            glBegin(GL_QUAD_STRIP);
            for (int i = 0; i <= platform_segments; ++i) {
                float angle = 2 * M_PI * i / platform_segments;
                float t = h / platform_height;
                float r = (1-t)*0.98f + t*0.82f;
                float g = (1-t)*0.78f + t*0.59f;
                float b = (1-t)*0.60f + t*0.38f;
                glColor3f(r, g, b);
                float r_top = platform_radius;
                float r_bot = platform_radius;
                glVertex3f(r_top * cos(angle), r_top * sin(angle), h + layerStep);
                glVertex3f(r_bot * cos(angle), r_bot * sin(angle), h);
            }
            glEnd();
        }
        glPushMatrix();
        glColor3f(0.80f, 0.54f, 0.32f);
        glBegin(GL_POLYGON);
        for (int i = 0; i < platform_segments; ++i) {
            float angle = 2 * M_PI * i / platform_segments;
            float r = platform_radius;
            glVertex3f(r * cos(angle), r * sin(angle), 0);
        }
        glEnd();
        glPopMatrix();
    }

    void drawPlatformTop() {
        glPushMatrix();
        glTranslatef(0, 0, platform_height + 0.004f);
        glBegin(GL_POLYGON);
        for (int i = 0; i < platform_segments; ++i) {
            float angle = 2 * M_PI * i / platform_segments;
            float r = platform_radius;
            float t = (float)i / platform_segments;
            float rr = (1-t)*0.98f + t*0.93f;
            float gg = (1-t)*0.89f + t*0.75f;
            float bb = (1-t)*0.70f + t*0.55f;
            glColor3f(rr, gg, bb);
            glVertex3f(r * cos(angle), r * sin(angle), 0);
        }
        glEnd();
        glPopMatrix();
    }

    void drawStar() {
        glPushMatrix();
        glTranslatef(0, 0, platform_height + 0.031f);
        glColor3f(0.46f, 0.86f, 0.95f);
        glBegin(GL_TRIANGLE_FAN);
        glVertex3f(0, 0, 0);
        for (int i = 0; i <= 2 * star_points; ++i) {
            float angle = i * M_PI / star_points;
            float r = (i % 2 == 0) ? star_outer_radius : star_inner_radius;
            glVertex3f(r * cos(angle), r * sin(angle), 0);
        }
        glEnd();
        glColor3f(0.81f, 0.89f, 0.95f);
        glBegin(GL_TRIANGLE_FAN);
        glVertex3f(0, 0, 0.008f);
        for (int i = 0; i <= 24; ++i) {
            float angle = 2 * M_PI * i / 24;
            glVertex3f(0.62f * star_inner_radius * cos(angle), 0.62f * star_inner_radius * sin(angle), 0.008f);
        }
        glEnd();
        glPopMatrix();
    }

    void drawGrassLayerWide(float R1, float R2, float height, float z, int segs, float angle_offset, float colR, float colG, float colB) {
        glColor3f(colR, colG, colB);
        for (int i = 0; i < segs; ++i) {
            float angle = 2 * M_PI * i / segs + angle_offset;
            float next_angle = 2 * M_PI * (i+1) / segs + angle_offset;
            float spike_h = height * (0.92f + 0.23f * ((i%3==0)?1:0) + 0.12f * sin(angle*5.4f));
            glBegin(GL_TRIANGLES);
            glVertex3f(R1 * cos(angle), R1 * sin(angle), z);
            glVertex3f(R1 * cos(next_angle), R1 * sin(next_angle), z);
            float avg_angle = (angle + next_angle) / 2.0f;
            glVertex3f(R2 * cos(avg_angle), R2 * sin(avg_angle), z + spike_h);
            glEnd();
        }
    }

    void drawMultiLayerGrassRing(float base_r, float h, float base_z) {
        int segs = 1200;
        drawGrassLayerWide(base_r * 1.040f, base_r * 1.027f, h * 1.40f, base_z + 0.028f, segs, 0.0f, 0.37f, 0.82f, 0.32f);
        drawGrassLayerWide(base_r * 1.025f, base_r * 1.017f, h * 1.22f, base_z + 0.020f, segs, M_PI / (segs * 1.15f), 0.50f, 0.99f, 0.61f);
        drawGrassLayerWide(base_r * 1.015f, base_r * 1.009f, h * 1.10f, base_z + 0.013f, segs, M_PI / (segs * 1.08f), 0.68f, 1.0f, 0.68f);
        drawGrassLayerWide(base_r * 1.008f, base_r * 1.003f, h * 0.99f, base_z + 0.006f, segs, M_PI / (segs * 0.96f), 0.58f, 0.97f, 0.57f);
        drawGrassLayerWide(base_r * 1.000f, base_r * 0.995f, h * 0.90f, base_z - 0.002f, segs, M_PI / (segs * 0.82f), 0.42f, 0.95f, 0.48f);
        drawGrassLayerWide(base_r * 0.990f, base_r * 0.985f, h * 0.75f, base_z - 0.011f, segs, M_PI / (segs/2), 0.28f, 0.71f, 0.26f);
        drawGrassLayerWide(base_r * 0.978f, base_r * 0.973f, h * 0.60f, base_z - 0.022f, segs, M_PI / (segs/3.4f), 0.15f, 0.52f, 0.16f);
    }

    void drawBattlePlatform() {
        drawPlatformBase();
        drawPlatformTop();
        drawStar();
        drawMultiLayerGrassRing(platform_radius * 1.000f, 0.28f, platform_height + 0.004f);
    }

    void drawFloatingStoneAnimated(float x, float y, float base_z, float scale, float phase) {
        float t = glutGet(GLUT_ELAPSED_TIME) / 1000.0f;
        float z = base_z + 0.7f * sin(t * 1.1f + phase);
        float angle = fmod(t*35 + phase*60, 360.0f);
        glPushMatrix();
        glTranslatef(x, y, z);
        glRotatef(angle, 0.15f + 0.2f*phase, 0.9f-0.15f*phase, 0.4f+0.1f*phase);
        glScalef(scale, scale, scale * (0.53f + 0.06f*sin(phase*1.3f)));
        float col = 0.65f + 0.09f * sin(phase*1.3f);
        glColor3f(col, 0.73f-0.08f*phase, 0.44f+0.05f*phase);
        glutSolidOctahedron();
        glPopMatrix();
    }

    void drawCloud3D(float x, float y, float z, float base_r, float phase, float speed) {
        float t = glutGet(GLUT_ELAPSED_TIME) / 1000.0f;
        float cx = x + sin(t * speed + phase) * 3.0f;
        struct Puff {
            float dx, dy, dz, r, alpha, pulse;
        };
        Puff puffs[] = {
            {  0.0f,  0.0f,  0.0f, 1.0f, 0.43f, 0.06f },
            { -0.75f, 0.19f, 0.05f, 0.73f, 0.31f, 0.11f },
            {  0.77f,-0.10f,-0.08f, 0.66f, 0.27f, 0.13f },
            { -0.38f, 0.40f,-0.21f, 0.54f, 0.21f, 0.12f },
            {  0.36f, 0.43f, 0.17f, 0.55f, 0.21f, 0.10f },
            {  0.00f,-0.55f, 0.00f, 0.46f, 0.17f, 0.09f },
            { -0.60f,-0.33f, 0.14f, 0.38f, 0.13f, 0.11f },
            {  0.64f,-0.36f,-0.15f, 0.36f, 0.13f, 0.08f },
            {  0.00f, 0.00f, 0.45f, 0.32f, 0.09f, 0.07f }
        };
        glPushMatrix();
        glTranslatef(cx, y, z);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glDisable(GL_LIGHTING);
        for (int i = 0; i < 9; ++i) {
            float pulse = 1.0f + 0.06f * sin(t * 0.8f + phase + i) * puffs[i].pulse;
            glPushMatrix();
            glTranslatef(puffs[i].dx * base_r, puffs[i].dy * base_r, puffs[i].dz * base_r);
            glColor4f(1.0f, 1.0f, 1.0f, puffs[i].alpha);
            glutSolidSphere(base_r * puffs[i].r * pulse, 30, 24);
            glPopMatrix();
        }
        glEnable(GL_LIGHTING);
        glDisable(GL_BLEND);
        glPopMatrix();
    }

}
