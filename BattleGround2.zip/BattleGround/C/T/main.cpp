#include <GL/glut.h>
#include <cmath>
#include "battleground.hpp"

// 旋转变量
float angleX = 22.0f, angleY = -34.0f;
int lastMouseX = 0, lastMouseY = 0;
bool isDragging = false;

// 鼠标事件
void mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON) {
        isDragging = (state == GLUT_DOWN);
        lastMouseX = x;
        lastMouseY = y;
    }
}
void motion(int x, int y) {
    if (isDragging) {
        angleY += (x - lastMouseX) * 0.8f;
        angleX += (y - lastMouseY) * 0.8f;
        if (angleX > 85) angleX = 85;
        if (angleX < -85) angleX = -85;
        lastMouseX = x;
        lastMouseY = y;
        glutPostRedisplay();
    }
}

// 光照
void setupLight() {
    GLfloat light_pos[] = {13, -14, 23, 1};
    GLfloat light_amb[] = {0.60, 0.60, 0.65, 1};
    GLfloat light_dif[] = {0.98, 0.98, 0.98, 1};
    glLightfv(GL_LIGHT0, GL_POSITION, light_pos);
    glLightfv(GL_LIGHT0, GL_AMBIENT, light_amb);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_dif);
    glEnable(GL_LIGHT0);
    glEnable(GL_LIGHTING);
}
void init() {
    glEnable(GL_DEPTH_TEST);
    setupLight();
    glEnable(GL_COLOR_MATERIAL);
    glClearColor(0.68f, 0.85f, 1.0f, 1.0f); // 天空蓝
}
void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(38, (float)w / h, 1, 80);
    glMatrixMode(GL_MODELVIEW);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    gluLookAt(0, -14, 7, 0, 0, 0.27, 0, 0, 1);

    glRotatef(angleX, 1, 0, 0);
    glRotatef(angleY, 0, 0, 1);

    // 画圆形平台+立体草环
    BattleGround::drawBattlePlatform();

    // 立体云朵（多点分布，环绕感）
    BattleGround::drawCloud3D(-8, 10, 4.5f, 1.4f, 0.2f, 0.11f);
    BattleGround::drawCloud3D(8, 12, 6.2f, 1.16f, 0.9f, 0.16f);
    BattleGround::drawCloud3D(0, 13.5f, 4.7f, 1.8f, 2.2f, 0.13f);
    BattleGround::drawCloud3D(7.5f, -6.8f, 5.9f, 1.35f, 1.5f, 0.14f);
    BattleGround::drawCloud3D(-7.7f, -7.7f, 5.6f, 1.05f, 2.9f, 0.12f);

    // 漂浮石块
    BattleGround::drawFloatingStoneAnimated(-6, 3, 2, 0.92f, 0.4f);
    BattleGround::drawFloatingStoneAnimated(6, -5, 2.2, 0.74f, 0.9f);
    BattleGround::drawFloatingStoneAnimated(3.8, 6, 0.9, 0.89f, 1.6f);
    BattleGround::drawFloatingStoneAnimated(-7.6, -8, 1.3, 1.07f, 2.7f);

    glutSwapBuffers();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(1100, 800);
    glutCreateWindow("3D Battle Platform - Round + Grass Ring");
    init();
    glutDisplayFunc(display);
    glutIdleFunc(display);
    glutReshapeFunc(reshape);
    glutMouseFunc(mouse);
    glutMotionFunc(motion);
    glutMainLoop();
    return 0;
}
