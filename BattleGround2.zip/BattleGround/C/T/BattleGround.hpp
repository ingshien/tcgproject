#ifndef BATTLEGROUND_HPP
#define BATTLEGROUND_HPP

namespace BattleGround {
    void drawBattlePlatform();

    void drawFloatingStoneAnimated(float x, float y, float base_z, float scale, float phase);

    void drawCloud3D(float x, float y, float z, float base_r, float phase = 0.0f, float speed = 1.0f);
}

#endif
