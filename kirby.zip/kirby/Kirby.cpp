#include "Kirby.hpp"
#include <iostream>
#include <ctime>
#include <cmath> // Needed for sin/cos in animation

using namespace std;

namespace Kirby
{
    MyVirtualWorld::MyVirtualWorld()
    {
        rotX = 0.0f;
        rotY = 0.0f;
        rotZ = 0.0f;

        rotSpeedX = 0.2f;
        rotSpeedY = 0.6f;
        rotSpeedZ = 0.0f;

        bodyRadius = 5.0;
        slices = 30;
        stacks = 30;

        isAnimating = true;
        isWireframe = false; // NEW: default solid

        armAngle = 0.0f;
        legAngle = 0.0f;
    }

    void MyVirtualWorld::init()
    {
        srand(static_cast<unsigned int>(time(NULL)));
        cout << "Kirby Character Initialized" << endl;
    }

    void MyVirtualWorld::tickTime()
    {
        if (!isAnimating) return;

        float time = glutGet(GLUT_ELAPSED_TIME) / 1000.0f;
        armAngle = 30.0f * sinf(time * 2.0f);
        legAngle = 30.0f * cosf(time * 2.0f);
    }

    void drawKirbyEye(float x, float y, float z, float radius, GLUquadric* quad)
    {
        float forwardZ = z + 0.5f;

        // Black base
        glColor3f(0.0f, 0.0f, 0.0f);
        glPushMatrix();
        glTranslatef(x, y, forwardZ);
        glScalef(0.8f, 2.0f, 0.6f);
        gluSphere(quad, radius, 20, 20);
        glPopMatrix();

        // White highlight
        glColor3f(1.0f, 1.0f, 1.0f);
        glPushMatrix();
        glTranslatef(x, y + radius * 0.4f, forwardZ + 0.01f);
        glScalef(0.6f, 1.5f, 0.6f);
        gluSphere(quad, radius, 20, 20);
        glPopMatrix();

        // Blue bottom highlight
        glColor3f(0.0f, 0.5f, 1.0f);
        glPushMatrix();
        glTranslatef(x, y - radius * 0.5f, forwardZ + 0.01f);
        glScalef(0.6f, 1.4f, 0.6f);
        gluSphere(quad, radius, 20, 20);
        glPopMatrix();
    }

    void MyVirtualWorld::draw()
    {
        glPushMatrix();
        glRotatef(rotX, 1.0f, 0.0f, 0.0f);
        glRotatef(rotY, 0.0f, 1.0f, 0.0f);
        glRotatef(rotZ, 0.0f, 0.0f, 1.0f);

        glColor3f(1.0f, 0.6f, 0.9f);
        GLUquadricObj* body = gluNewQuadric();

        // ✅ Wireframe or solid mode
        gluQuadricDrawStyle(body, isWireframe ? GLU_LINE : GLU_FILL);
        gluQuadricNormals(body, GLU_SMOOTH);

        // Kirby's body
        gluSphere(body, bodyRadius, slices, stacks);

        // Feet
        glColor3f(1.0f, 0.3f, 0.3f);

        glPushMatrix();
        glTranslatef(-bodyRadius/1.8f, -bodyRadius*0.85f, 0.0f);
        glRotatef(legAngle, 1, 0, 0);
        glScalef(1.3f, 0.8f, 1.5f);
        gluSphere(body, bodyRadius/2.5f, slices, stacks);
        glPopMatrix();

        glPushMatrix();
        glTranslatef(bodyRadius/1.8f, -bodyRadius*0.85f, 0.0f);
        glRotatef(-legAngle, 1, 0, 0);
        glScalef(1.3f, 0.8f, 1.5f);
        gluSphere(body, bodyRadius/2.5f, slices, stacks);
        glPopMatrix();

        // Arms
        glColor3f(1.0f, 0.6f, 0.9f);

        glPushMatrix();
        glTranslatef(-bodyRadius*1.0f, 0.0f, 0.0f);
        glRotatef(armAngle, 0.0f, 0.0f, 1.0f);
        glScalef(0.4f, 0.4f, 0.4f);
        gluSphere(body, bodyRadius, slices, stacks);
        glPopMatrix();

        glPushMatrix();
        glTranslatef(bodyRadius*1.0f, 0.0f, 0.0f);
        glRotatef(-armAngle, 0.0f, 0.0, 1.0f);
        glScalef(0.4f, 0.4f, 0.4f);
        gluSphere(body, bodyRadius, slices, stacks);
        glPopMatrix();

        // Eyes
        float eyeRadius = bodyRadius / 6.0f;
        float eyeZ = bodyRadius * 0.85f;
        drawKirbyEye(-bodyRadius * 0.25f, bodyRadius * 0.25f, eyeZ, eyeRadius, body);
        drawKirbyEye(bodyRadius * 0.25f, bodyRadius * 0.25f, eyeZ, eyeRadius, body);

        // Mouth
        glColor3f(1.0f, 0.0f, 0.5f);
        glPushMatrix();
        glTranslatef(0.0f, -bodyRadius*0.2f, bodyRadius*0.8f);
        glScalef(0.4f, 0.7f, 0.8f);
        gluSphere(body, bodyRadius/3.5f, slices, stacks);
        glPopMatrix();

        // Cheeks
        glColor3f(1.0f, 0.3f, 0.7f);

        glPushMatrix();
        glTranslatef(-bodyRadius*0.5f, -0.8f, bodyRadius*0.7f);
        glScalef(2.5f, 0.8f, 2.0f);
        gluSphere(body, bodyRadius/8.0f, slices, stacks);
        glPopMatrix();

        glPushMatrix();
        glTranslatef(bodyRadius*0.5f, -0.8f, bodyRadius*0.7f);
        glScalef(2.5f, 0.8f, 2.0f);
        gluSphere(body, bodyRadius/8.0f, slices, stacks);
        glPopMatrix();

        gluDeleteQuadric(body);
        glPopMatrix();
    }

    void MyVirtualWorld::toggleAnimation()
    {
        isAnimating = !isAnimating;
    }

    void MyVirtualWorld::toggleWireframe()
    {
        isWireframe = !isWireframe;
    }
}
