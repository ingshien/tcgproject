#ifndef YP_KIRBY_HPP
#define YP_KIRBY_HPP

#include <cmath>
#include <GL/glut.h>

namespace Kirby
{
    class MyVirtualWorld
    {
    private:
        // Rotation angles for Kirby
        GLfloat rotX, rotY, rotZ;

        // Rotation speeds
        GLfloat rotSpeedX, rotSpeedY, rotSpeedZ;

        // Kirby body parameters
        GLdouble bodyRadius;
        GLint slices, stacks;

        // Animation control
        bool isAnimating;

        // New animation angles for limbs
        GLfloat armAngle;
        GLfloat legAngle;

        // 🔄 Wireframe toggle
        bool isWireframe;

    public:
        MyVirtualWorld();
        void init();
        void draw();
        void tickTime();
        void toggleAnimation();
        void toggleWireframe(); // ✅ Toggle wireframe mode
    };
}

#endif // YP_KIRBY_HPP

